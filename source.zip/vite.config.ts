import {readFileSync} from 'node:fs';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';
import {defineConfig} from 'vite';
import {fileURLToPath} from 'node:url';
export default defineConfig({
  base:'./',
  plugins:[react(),{name:'local-ledger-file',configureServer(server){server.middlewares.use('/data/ledger.json',(_req,res)=>{res.setHeader('Content-Type','application/json; charset=utf-8');res.end(readFileSync(new URL('./docs/data/ledger.json',import.meta.url)));});}}],
  resolve:{alias:{'@':fileURLToPath(new URL('.',import.meta.url))}},
  css:{postcss:{plugins:[tailwindcss()]}},
  build:{outDir:'dist',emptyOutDir:true},
});
