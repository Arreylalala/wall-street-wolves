'use client';
import { useEffect, useState } from 'react';
import {
  Trophy,
  ArrowUpRight,
  ArrowLeft,
  ArrowRight,
  ChartNoAxesCombined,
  Users,
  CalendarDays,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '@/components/ui/table';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import {
  members,
  winners,
  valueOf,
  today,
  type Day,
  type Mode,
} from '@/lib/ledger';
import {validateLedger,monthData} from '@/lib/data';
export default function Dashboard() {
  const [month, setMonth] = useState(today().slice(0, 7)),
    [mode, setMode] = useState<Mode>('rate'),
    [person, setPerson] = useState('all'),
    [data, setData] = useState<{ days: Day[]; capitals: number[] } | null>(
      null,
    ),
    [error, setError] = useState('');
  useEffect(() => {
    const c = new AbortController();
    setData(null);
    setError('');
    fetch(new URL('data/ledger.json', document.baseURI), { signal: c.signal, cache: 'no-store' })
      .then((r) => {
        if (!r.ok) throw Error('数据加载失败，请刷新重试');
        return r.json();
      })
      .then(raw=>setData(monthData(validateLedger(raw),month)))
      .catch((e) => {
        if (e.name !== 'AbortError') setError(e.message);
      });
    return () => c.abort();
  }, [month]);
  const days = data?.days || [],
    caps = data?.capitals || members.map((m) => m.capital),
    shown = members
      .map((m, i) => i)
      .filter((i) => person === 'all' || members[i].id === person),
    total = members.map((_, i) =>
      days.reduce((s, d) => s + (d.values[i] ?? 0), 0),
    ),
    counts = members.map(
      (_, i) =>
        days.filter((d) => winners(d.values, caps, mode).includes(i)).length,
    ),
    latest = days.at(-1),
    has = members.map((_, i) => days.some((d) => d.values[i] !== null)),
    rank = [0, 1, 2, 3].sort(
      (a, b) =>
        Number(has[b]) - Number(has[a]) ||
        valueOf(total[b], caps[b], mode) - valueOf(total[a], caps[a], mode),
    );
  const fmt = (v: number | null, i: number) =>
    v === null
      ? '待录入'
      : (v > 0 ? '+' : '') +
        valueOf(v, caps[i], mode).toLocaleString('zh-CN', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        }) +
        (mode === 'rate' ? '%' : '');
  const running = [0, 0, 0, 0];
  const chart = days.map((d) => {
    const row: Record<string, number | string | null> = {
      date: d.date.slice(5),
    };
    members.forEach((m, i) => {
      if (d.values[i] !== null) running[i] += d.values[i]!;
      row[m.name] =
        d.values[i] === null ? null : valueOf(running[i], caps[i], mode);
    });
    return row;
  });
  function shift(n: number) {
    const d = new Date(month + '-01T12:00:00Z');
    d.setUTCMonth(d.getUTCMonth() + n);
    setMonth(d.toISOString().slice(0, 7));
  }
  return (
    <div className="shell">
      <header className="topbar">
        <a href="./" className="brand">
          <span className="brandmark">
            <ChartNoAxesCombined size={23} />
          </span>
          谁是华尔街之狼<span className="brandtag">WOLF PACK · 04</span>
        </a>
        <span className="friend-badge">🐺 四人友谊赛</span>
      </header>
      <main>
        <div className="heading">
          <div>
            <div className="eyebrow">FRIENDS FIRST. WOLVES AT CLOSE.</div>
            <h1>
              友谊第一，今天谁当狼<span>。</span>
            </h1>
            <p>收盘见真章，今天的吹牛资格花落谁家？</p>
          </div>
          <div className="market">
            <span />A 股 · 人民币
          </div>
        </div>
        <div className="toolbar">
          <div className="month-control">
            <button aria-label="上个月" onClick={() => shift(-1)}>
              <ArrowLeft size={16} />
            </button>
            <label>
              <CalendarDays size={17} />
              <input
                aria-label="选择月份"
                type="month"
                value={month}
                onChange={(e) => e.target.value && setMonth(e.target.value)}
              />
            </label>
            <button aria-label="下个月" onClick={() => shift(1)}>
              <ArrowRight size={16} />
            </button>
          </div>
          <Tabs value={mode} onValueChange={(v) => setMode(v as Mode)}>
            <TabsList>
              <TabsTrigger value="amount">收益金额 ¥</TabsTrigger>
              <TabsTrigger value="rate">收益率 %</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <div className="section-title">
          <h2>
            本月战绩 <span>MONTHLY OVERVIEW</span>
          </h2>
          <small>
            {days.length} 个记录日 ·{' '}
            {mode === 'rate' ? '按固定本金计算' : '累计盈亏金额'}
          </small>
        </div>
        {error && (
          <div className="notice" role="alert">
            {error}
            <button onClick={() => location.reload()}>重试</button>
          </div>
        )}
        <div className="score-grid">
          {members.map((m, i) => (
            <button
              key={m.id}
              className={'score ' + (person === m.id ? 'selected' : '')}
              onClick={() => setPerson(person === m.id ? 'all' : m.id)}
              style={{ '--member': m.color } as React.CSSProperties}
            >
              <div className="score-top">
                <span className="avatar">{m.name}</span>
                <span>
                  {m.name}
                  <small>本月累计{mode === 'rate' ? '收益率' : '收益'}</small>
                </span>
                <ArrowUpRight size={18} />
              </div>
              <strong
                className={
                  total[i] > 0 ? 'positive' : total[i] < 0 ? 'negative' : ''
                }
              >
                {!data ? '…' : has[i] ? fmt(total[i], i) : '—'}
                <em>{mode === 'amount' && has[i] ? '元' : ''}</em>
              </strong>
              <div className="score-foot">
                <span>
                  <Trophy size={14} />
                  {counts[i]} 次{mode === 'amount' ? '金额' : '收益率'}冠军
                </span>
                <span>
                  {has[i]
                    ? '已录 ' +
                      days.filter((d) => d.values[i] !== null).length +
                      ' 天'
                    : '等待首笔记录'}
                </span>
              </div>
            </button>
          ))}
        </div>
        <div className="workspace">
          <section className="panel trend">
            <div className="panel-heading">
              <div>
                <h2>收益走势</h2>
                <p>本月累计{mode === 'rate' ? '收益率 · %' : '收益 · 元'}</p>
              </div>
              <Tabs value={person} onValueChange={(v) => setPerson(String(v))}>
                <TabsList>
                  <TabsTrigger value="all">全部</TabsTrigger>
                  {members.map((m) => (
                    <TabsTrigger key={m.id} value={m.id}>
                      {m.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            </div>
            {days.length ? (
              <>
                <div className="legend">
                  {shown.map((i) => (
                    <span key={i}>
                      <b style={{ background: members[i].color }} />
                      {members[i].name}
                    </span>
                  ))}
                </div>
                <div className="chart">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={chart}
                      margin={{ top: 12, right: 18, bottom: 4, left: 0 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 5"
                        vertical={false}
                        stroke="#e9ebf2"
                      />
                      <XAxis
                        dataKey="date"
                        tick={{ fontSize: 12 }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis
                        width={66}
                        tick={{ fontSize: 12 }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <Tooltip
                        formatter={(v) =>
                          Number(v).toFixed(2) + (mode === 'rate' ? '%' : ' 元')
                        }
                      />
                      <ReferenceLine y={0} stroke="#b9bfd0" />
                      {shown.map((i) => (
                        <Line
                          key={i}
                          dataKey={members[i].name}
                          stroke={members[i].color}
                          strokeWidth={2.5}
                          dot={{ r: 3 }}
                          connectNulls={false}
                        />
                      ))}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </>
            ) : (
              <div className="empty-chart">
                <ChartNoAxesCombined size={36} />
                <h3>{error ? '战绩暂时未能加载' : data ? '本月狼王，等你开局' : '正在加载战绩'}</h3>
                <p>
                  {error ? '请检查数据文件后刷新重试。' : data
                    ? '首日战绩更新后，四位选手的走势将在这里展开。'
                    : '正在读取每日记录…'}
                </p>
                <div className="empty-lines" />
              </div>
            )}
          </section>
          <aside className="panel podium">
            <div className="panel-heading">
              <h2>
                <Trophy size={19} /> 今日头狼
              </h2>
              <span className="pill">
                {mode === 'rate' ? '收益率冠军' : '金额冠军'}
              </span>
            </div>
            <div className="winner-area">
              <span className="trophy-orbit">
                <Trophy size={30} />
              </span>
              <small>{latest ? latest.date : '尚未结算'}</small>
              <h3>
                {latest
                  ? winners(latest.values, caps, mode)
                      .map((i) => members[i].name)
                      .join(' · ') || '等待录齐'
                  : '虚位以待'}
              </h3>
              <p>
                {latest
                  ? winners(latest.values, caps, mode).length
                    ? '今日 C 位，属于你。'
                    : '四人数据齐全后自动评选冠军。'
                  : '狼王宝座，等你来坐。'}
              </p>
            </div>
            <div className="rank-label">
              本月{mode === 'rate' ? '收益率' : '金额'}排名
            </div>
            {rank.map((i, idx) => (
              <div className="rank-row" key={i}>
                <span className="rank-number">
                  {has[i]
                    ? 1 +
                      rank.filter(
                        (j) =>
                          has[j] &&
                          valueOf(total[j], caps[j], mode) >
                            valueOf(total[i], caps[i], mode),
                      ).length
                    : '—'}
                </span>
                <b style={{ color: members[i].color }}>{members[i].name}</b>
                <span
                  className={
                    total[i] > 0 ? 'positive' : total[i] < 0 ? 'negative' : ''
                  }
                >
                  {has[i] ? fmt(total[i], i) : '待录入'}
                </span>
              </div>
            ))}
          </aside>
        </div>
        <section className="panel records">
          <div className="panel-heading">
            <div>
              <h2>每日明细</h2>
              <p>
                {person === 'all'
                  ? '四人同场，一目了然'
                  : members.find((m) => m.id === person)?.name +
                    '的每日表现'}{' '}
                · {mode === 'rate' ? '收益率 %' : '金额 ¥'}
              </p>
            </div>
            <span className="readonly">
              <Users size={14} />
              公开只读
            </span>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>结算日期</TableHead>
                {shown.map((i) => (
                  <TableHead key={i}>{members[i].name}</TableHead>
                ))}
                <TableHead>{mode === 'rate' ? '收益率' : '金额'}冠军</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...days].reverse().map((d) => (
                <TableRow key={d.date}>
                  <TableCell>{d.date}</TableCell>
                  {shown.map((i) => (
                    <TableCell
                      key={i}
                      className={
                        (d.values[i] ?? 0) > 0
                          ? 'positive'
                          : (d.values[i] ?? 0) < 0
                            ? 'negative'
                            : ''
                      }
                    >
                      {fmt(d.values[i], i)}
                    </TableCell>
                  ))}
                  <TableCell>
                    <span className="winner-label">
                      {winners(d.values, caps, mode)
                        .map((i) => members[i].name)
                        .join('、') || '待录齐'}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
              {!days.length && (
                <TableRow>
                  <TableCell colSpan={shown.length + 2} className="empty-cell">
                    {data
                      ? '本月暂无记录，录入后会自动汇总到这里。'
                      : '正在读取记录…'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </section>
        <footer>
          <span>
            谁是华尔街之狼 <b>·</b> 认真比赛，快乐嘴硬。
          </span>
          <span>红涨绿跌 · 最近结算：{latest?.date || '暂无'} · 北京时间</span>
        </footer>
      </main>
    </div>
  );
}
