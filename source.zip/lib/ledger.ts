export const members = [
  { id: 'lun', name: '伦', capital: 200000, color: '#7145e8' },
  { id: 'lei', name: '镭', capital: 600000, color: '#009e92' },
  { id: 'jian', name: '健', capital: 20000, color: '#d88300' },
  { id: 'chao', name: '超', capital: 150000, color: '#d7438c' },
];
export type Day = { date: string; values: (number | null)[]; revision: number };
export type Mode = 'amount' | 'rate';
export function winners(
  values: (number | null)[],
  capitals: number[],
  mode: Mode,
) {
  if (values.length !== 4 || values.some((v) => v === null)) return [];
  const compare = (i: number, j: number) =>
    mode === 'amount'
      ? BigInt(values[i]!) - BigInt(values[j]!)
      : BigInt(values[i]!) * BigInt(Math.round(capitals[j] * 100)) -
        BigInt(values[j]!) * BigInt(Math.round(capitals[i] * 100));
  let best = 0;
  for (let i = 1; i < 4; i++) if (compare(i, best) > BigInt(0)) best = i;
  return [0, 1, 2, 3].filter((i) => compare(i, best) === BigInt(0));
}
export function valueOf(v: number, c: number, mode: Mode) {
  return mode === 'amount' ? v / 100 : v / c;
}
export function today() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}
