import {members,type Day} from './ledger.ts';
export type LedgerData={months:Record<string,{capitals:Record<string,number>;days:Array<{date:string;returns:Record<string,number|null>}>}>};
const monthPattern=/^20\d{2}-(0[1-9]|1[0-2])$/;
export function validateLedger(input:unknown):LedgerData{
 if(!input||typeof input!=='object'||!('months' in input)||!input.months||typeof input.months!=='object'||Array.isArray(input.months))throw Error('数据文件格式错误：缺少 months');
 for(const [month,raw] of Object.entries(input.months)){
  if(!monthPattern.test(month)||!raw||typeof raw!=='object')throw Error('月份格式应为 YYYY-MM');
  const m=raw as LedgerData['months'][string];
  for(const p of members){const c=m.capitals?.[p.name];if(typeof c!=='number'||!Number.isFinite(c)||c<=0||c>1e9||Math.abs(c*100-Math.round(c*100))>0.00001)throw Error(month+'：请检查'+p.name+'的本金');}
  if(!Array.isArray(m.days))throw Error(month+'：days 必须为数组');
  const seen=new Set();for(const d of m.days){if(!d||typeof d.date!=='string'||!/^20\d{2}-\d{2}-\d{2}$/.test(d.date)||!d.date.startsWith(month+'-')||Number.isNaN(Date.parse(d.date))||new Date(d.date+'T12:00:00Z').toISOString().slice(0,10)!==d.date)throw Error(month+'：日期无效或不属于该月份');if(seen.has(d.date))throw Error(d.date+'：日期重复');seen.add(d.date);
   for(const p of members){const v=d.returns?.[p.name];if(v!==null&&(typeof v!=='number'||!Number.isFinite(v)||Math.abs(v)>1e9||Math.abs(v*100-Math.round(v*100))>0.00001))throw Error(d.date+'：'+p.name+'收益必须是最多两位小数的金额或 null');}
  }
 }
 return input as LedgerData;
}
export function monthData(ledger:LedgerData,month:string):{days:Day[];capitals:number[]}{const m=ledger.months[month];return {capitals:m?members.map(p=>m.capitals[p.name]):members.map(p=>p.capital),days:m?[...m.days].sort((a,b)=>a.date.localeCompare(b.date)).map(d=>({date:d.date,values:members.map(p=>d.returns[p.name]===null?null:Math.round(d.returns[p.name]!*100)),revision:0})):[]};}
