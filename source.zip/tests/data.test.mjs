import test from 'node:test';import assert from 'node:assert/strict';
import {validateLedger,monthData} from '../lib/data.ts';
const capitals={'伦':200000,'镭':600000,'健':20000,'超':150000};
const day={date:'2026-09-01',returns:{'伦':1000.12,'镭':-200,'健':null,'超':0}};
const fixture=()=>({months:{'2026-09':{capitals,days:[structuredClone(day)]}}});
test('元转换为分，null 和零保留，月份独立',()=>{const d=fixture();d.months['2026-10']={capitals:{...capitals,'伦':300000},days:[]};validateLedger(d);assert.deepEqual(monthData(d,'2026-09').days[0].values,[100012,-20000,null,0]);assert.equal(monthData(d,'2026-09').capitals[0],200000);assert.equal(monthData(d,'2026-10').capitals[0],300000);assert.deepEqual(monthData(d,'2026-11').days,[])});
test('拒绝重复日期、无效日期、缺失收益和三位小数',()=>{let d=fixture();d.months['2026-09'].days.push(day);assert.throws(()=>validateLedger(d),/重复/);d=fixture();d.months['2026-09'].days[0].date='2026-09-31';assert.throws(()=>validateLedger(d),/日期/);d=fixture();delete d.months['2026-09'].days[0].returns['健'];assert.throws(()=>validateLedger(d),/收益/);d=fixture();d.months['2026-09'].days[0].returns['伦']=.123;assert.throws(()=>validateLedger(d),/收益/)});
