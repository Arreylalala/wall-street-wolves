import test from 'node:test';
import assert from 'node:assert/strict';
import { winners, valueOf } from '../lib/ledger.ts';
const caps = [200000, 600000, 20000, 150000];
test('金额和收益率可评出不同冠军', () => {
  const v = [100000, 200000, 50000, 100000];
  assert.deepEqual(winners(v, caps, 'amount'), [1]);
  assert.deepEqual(winners(v, caps, 'rate'), [2]);
});
test('全部亏损、并列、零收益和未录齐', () => {
  assert.deepEqual(winners([-100, -200, -300, -400], caps, 'amount'), [0]);
  assert.deepEqual(winners([100, 100, -1, 0], caps, 'amount'), [0, 1]);
  assert.deepEqual(winners([0, 0, 0, 0], caps, 'rate'), [0, 1, 2, 3]);
  assert.deepEqual(winners([0, null, 0, 0], caps, 'amount'), []);
});
test('固定本金收益率与精确并列', () => {
  assert.equal(valueOf(100000, 200000, 'rate'), 0.5);
  assert.equal(valueOf(100000, 200000, 'amount'), 1000);
  assert.deepEqual(
    winners([20000, 60000, 2000, 15000], caps, 'rate'),
    [0, 1, 2, 3],
  );
});
