import {readFileSync} from 'node:fs';
import {validateLedger} from '../lib/data.ts';
validateLedger(JSON.parse(readFileSync('docs/data/ledger.json','utf8')));
console.log('收益数据校验通过');
