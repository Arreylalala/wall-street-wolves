import {cpSync,readFileSync,writeFileSync,mkdirSync,rmSync} from 'node:fs';
const data=readFileSync('docs/data/ledger.json');
rmSync('docs/assets',{recursive:true,force:true});
cpSync('dist','docs',{recursive:true});
mkdirSync('dist/data',{recursive:true});
writeFileSync('dist/data/ledger.json',data);
writeFileSync('docs/.nojekyll','');
writeFileSync('dist/.nojekyll','');
console.log('GitHub Pages 静态页面已生成到 docs/');
